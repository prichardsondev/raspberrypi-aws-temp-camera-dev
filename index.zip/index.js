// const axios = require('axios');

  
// const postData = async (data) => {
//     console.log(data);
//     const response = await axios.post('https://temp.raspberrynode.com', data);
//     console.log(response);
// };

// exports.handler = async (event, context) => {
   
//     for (const record of event.Records) {
//         let newImage = record.dynamodb.NewImage;
//         let temp = newImage.Temperature.S;
//         let name = newImage.PK.S;
        
//         let data = {name,temp};
//         await postData(data);
//     }
    
    
//     return `Successfully processed ${event.Records.length} records.`;
// };



const AWS = require("aws-sdk");
const rekognition = new AWS.Rekognition();
const axios = require('axios');

const postData = async (data) => {
    console.log(data);
    const response = await axios.post('https://temp.raspberrynode.com', data);
    console.log(response);
};


exports.handler = async (event) => {
    //console.log(event.Records[0]);
   
    const record = event.Records[0].s3;
    const bucket = record.bucket.name;
    const file = record.object.key;
   
    console.log(record,bucket,file);
   
   
    try {
        // const image = {
        //     Bucket: bucket,
        //     Key:file
        // };
       
        // let data = await getText(image);
        // console.log("data>>>>>>>>>>>>>>>> ", data);
        
        // let post = {
        //    bucket,data
        // };
        
        // await postData(post);
       
        // console.log(`published  ${data}`);
       
    } catch (e) {}
};

const getText = async (image) => {

    var params = {
        Image: {
            S3Object: {
                Bucket: image.Bucket,
                Name: image.Key
            }
        }
    };
    let data;
   
    try {
      data   = await rekognition.detectText(params).promise();
    } catch (e) {console.log("error>>>>>>>>>>>>>> ", e);}
   
   
    try {
        let words = await data.TextDetections.filter((word) => word.Type === "WORD")
        .map((filteredWord) => filteredWord.DetectedText + " ")
        .reduce((previous, current) => previous.concat(current), "");
       
         return words;
    } catch (e) {console.log('error>>>>>>>>>>>', e);}
};

